package org.example;

public class Call {

    public static void makeCall() {
        Driver driver = Driver.getInstance();

        //Allow contacts permission
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/img_back_arrow");

        //From Dialpad
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Dialpad\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeElementID("com.slickcall.app.dev:id/text_field", "923150999111");
        driver.clickElementID("com.slickcall.app.dev:id/fab_call");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_foreground_only_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); //Nearby permission
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        //From contacts
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Contacts\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeAndClick("com.slickcall.app.dev:id/et_search","Gm","com.slickcall.app.dev:id/tv_contact_name");
        driver.clickElementID("com.slickcall.app.dev:id/fab_call");
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        //Enter number Manually
        driver.clickElementID("com.slickcall.app.dev:id/tv_open_dial_pad");
        driver.typeElementID("com.slickcall.app.dev:id/text_field", "923150999111");
        driver.clickElementID("com.slickcall.app.dev:id/fab_call");
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        //From Recents
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Recents\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeElementID("com.slickcall.app.dev:id/et_search", "Gm");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.RelativeLayout[2]");
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        // Perform scroll up to logout
//        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
//        driver.scrollUp();
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
//        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");
    }
}
