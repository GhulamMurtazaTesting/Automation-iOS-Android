package org.example;

import io.appium.java_client.MobileElement;

public class Signup {

    public static void main(String[] args) {


//        TestWelcomeOffer();
//        testHappyFlow();


//        String ChangeNumber;
//        String[] phoneNumbers = {"2025551351", "2025551352", "2025551353"};
//
//        for (String phoneNumber : phoneNumbers) {
//            TestWelcomeOffer(phoneNumber);
//            testHappyFlow();

        SignUp();
//        SignupWithoutPermissions();

//        Login.Test3FunctionFlow();
//        Login.WrongCredentailsLogin();
//        Login.testLogin();

//        Call.makeCall();

        Plans.ActivatePlans();
    }

    public static void testHappyFlow() {
        Driver driver = Driver.getInstance();

//        // permission popup
////        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
////        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
//        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");
//
//        // Search and select country
//        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView
//
//        // Enter phone number and proceed
//        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550994", "com.slickcall.app.dev:id/btn_send_code");
//
//        // Enter OTP
//        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");
//
//        // Handle permissions
////        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); // Contacts
////        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); // Nearby

        //Do Top-up
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[5]/android.widget.RelativeLayout/android.widget.ImageButton");
        //Continue By card
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View[1]/android.view.View/android.widget.ListView/android.view.View/android.widget.Button");
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.EditText","4242424242424242");
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[2]/android.view.View/android.widget.EditText", "1236");
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.view.View[1]/android.widget.EditText","123");
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText","Kashif");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[3]/android.view.View[4]/android.view.View/android.view.View[1]/android.view.View/android.view.View");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[2]");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View[2]/android.widget.Button");
        driver.sleep(5000);
        driver.clickElementID("com.slickcall.app.dev:id/refresh_balance_icon");
        driver.sleep(5000);
        //Subscribe Slab plan
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
//        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Angola", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        MobileElement subscribeButton = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/btn_subscribe");
        // Check if the 10 minutes plan is already subscribed
        if(subscribeButton.getText().equalsIgnoreCase("subscribed")){
            driver.clickElementID("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout");
        }
        else{
        driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");}
        driver.clickElementID("com.slickcall.app.dev:id/ll_pay_with_wallet");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.Button");

        // Make call by entering number in Dialpad
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Dialpad\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeAndClick("com.slickcall.app.dev:id/text_field", "923150999111", "com.slickcall.app.dev:id/fab_call");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_foreground_only_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); //Nearby permission
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        // Perform scroll up to logout
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.scrollUp();
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");
    }


    public static void SignUp(){
        Driver driver = Driver.getInstance();

        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550993", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");

        // Use the generateRandomString method to get a random string
        String randomText = driver.generateRandomString(8); // Change 8 to the desired length
        driver.typeElementID("com.slickcall.app.dev:id/et_name", randomText);
        driver.clickElementID("com.slickcall.app.dev:id/dropDownArrow");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[1]"); //Multi-currency Selection
        driver.typeElementID("com.slickcall.app.dev:id/et_email", randomText+"@gmail.com");
        driver.clickElementID("com.slickcall.app.dev:id/btn_proceed");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/btn_skip");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Dialpad\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeElementID("com.slickcall.app.dev:id/text_field", "923150999111");
        driver.clickElementID("com.slickcall.app.dev:id/fab_call");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_foreground_only_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.sleep(4000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

    }
    public static void TestWelcomeOffer() {
        Driver driver = Driver.getInstance();
// Continue with card flow
        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United Kingdom", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "7762248162", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");

        // Use the generateRandomString method to get a random string
        String randomText = driver.generateRandomString(8); // Change 8 to the desired length
        driver.typeElementID("com.slickcall.app.dev:id/et_name", randomText);
        driver.clickElementID("com.slickcall.app.dev:id/dropDownArrow");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[1]"); //Multi-currency Selection
        driver.typeElementID("com.slickcall.app.dev:id/et_email", randomText+"@gmail.com");
        driver.clickElementID("com.slickcall.app.dev:id/btn_proceed");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/textView_selectedCountry");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Kenya", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/btn_next");
        driver.clickElementID("com.slickcall.app.dev:id/btn_activate");

        //Continue By card
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.EditText","4242424242424242");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[2]/android.view.View/android.widget.EditText", "1236");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.view.View[1]/android.widget.EditText","123");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText","Kashif");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View[3]/android.view.View[4]/android.view.View/android.view.View[1]/android.view.View/android.view.View");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[3]");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View[2]/android.widget.Button");


//        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
//        driver.scrollUp();
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
//        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");

// Continue with PayPal flow

//        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");
//
//        // Search and select country
//        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView
//
//        // Enter phone number and proceed
//        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550995", "com.slickcall.app.dev:id/btn_send_code");
//
//        // Enter OTP
//        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");
//
//
//        // Use the generateRandomString method to get a random string
//        String randomText1 = driver.generateRandomString(8); // Change 8 to the desired length
//        driver.typeElementID("com.slickcall.app.dev:id/et_name", randomText1);
//        driver.clickElementID("com.slickcall.app.dev:id/dropDownArrow");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[1]"); //Multi-currency Selection
//        driver.typeElementID("com.slickcall.app.dev:id/et_email", randomText1+"@gmail.com");
//        driver.clickElementID("com.slickcall.app.dev:id/btn_proceed");
//        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
//        driver.clickElementID("com.slickcall.app.dev:id/textView_selectedCountry");
//        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Kenya", "com.slickcall.app.dev:id/textView_countryName");
//        driver.clickElementID("com.slickcall.app.dev:id/btn_next");
//        driver.clickElementID("com.slickcall.app.dev:id/btn_activate");
//
//
//
//        //Continue by PayPal
//        driver.clickElementID("com.slickcall.app.dev:id/rbPaypal");
//        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View[1]/android.view.View/android.widget.EditText", "sb-ccomx8014149@personal.example.com");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.widget.Button");
//        driver.sleep(2000);
//        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.widget.EditText","DMn=40hu");
//        driver.sleep(2000);
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button");
//        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.Button");
//        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
    }
    public static void SignupWithoutPermissions() {
        Driver driver = Driver.getInstance();

        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/tv_deny"); // Popup for Permission
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550997", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");

        // Use the generateRandomString method to get a random string
        String randomText = driver.generateRandomString(8); // Change 8 to the desired length
        driver.typeElementID("com.slickcall.app.dev:id/et_name", randomText);
        driver.clickElementID("com.slickcall.app.dev:id/dropDownArrow");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[1]"); //Multi-currency Selection
        driver.typeElementID("com.slickcall.app.dev:id/et_email", randomText+"@gmail.com");
        driver.clickElementID("com.slickcall.app.dev:id/btn_proceed");
        driver.clickElementID("com.slickcall.app.dev:id/tv_deny"); //ContactsPermission
        driver.clickElementID("com.slickcall.app.dev:id/btn_skip");

        // Make call by entering number in Dialpad
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Dialpad\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeAndClick("com.slickcall.app.dev:id/text_field", "923150999111", "com.slickcall.app.dev:id/fab_call");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_foreground_only_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); //Nearby permission
        driver.sleep(20000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        // Perform scroll up to logout
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.scrollUp();
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");


    }
}