package org.example;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.Random;

import java.net.MalformedURLException;
import java.net.URL;

public class Driver {

    private final AndroidDriver<MobileElement> driver;
    private static Driver instance;


    public AndroidDriver<MobileElement> getHeavyDriver() {
        return driver;
    }

    public static Driver getInstance() {
        if (instance == null)
            instance = new Driver();
        return instance;
    }

    private Driver() {
        DesiredCapabilities desiredCapabilities = getDesiredCapabilities();

        try {
            driver = new AndroidDriver<>(new URL("http://localhost:4723/wd/hub"), desiredCapabilities);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

        try {
            Thread.sleep(2500);
        } catch (InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private static DesiredCapabilities getDesiredCapabilities() {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13.0");
        desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 4a");
        desiredCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
        desiredCapabilities.setCapability(MobileCapabilityType.APP, "C:\\Users\\Ghulam Murtaza\\Downloads\\app-dev-debug.apk");
        return desiredCapabilities;
    }

    public void clickElementID(String id) {
        waitForElement(By.id(id)).click();
    }

    public void clickElementXpath(String XPath) {
        waitForElement(By.xpath(XPath)).click();
    }

    public void typeElementID(String id, String text) {
        waitForElement(By.id(id)).sendKeys(text);
    }

    public void typeElementXpath(String XPath, String text) { waitForElement(By.xpath(XPath)).sendKeys(text);
    }

    public void typeAndClick(String inputId, String text, String clickId) {
        typeElementID(inputId, text);
        clickElementID(clickId);
    }

    public MobileElement  waitForElement(By by) {
        WebElement webElement = new WebDriverWait(driver, 20)
                .until(ExpectedConditions.visibilityOfElementLocated(by));
        return (MobileElement) webElement;
    }

    public void scrollUp() {
        // Get the size of the screen
        Dimension size = driver.manage().window().getSize();

        // Set the start and end points for the swipe
        int startX = size.width / 2;
        int startY = (int) (size.height * 0.8); // 80% from the bottom
        int endY = (int) (size.height * 0.2);   // 20% from the bottom

        // Perform the swipe
        driver.performTouchAction(new TouchAction<>(driver)
                .press(PointOption.point(startX, startY))
                .moveTo(PointOption.point(startX, endY))
                .release());
    }
    // Create a method to generate a random string
    public String generateRandomString(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            randomString.append(characters.charAt(index));
        }

        return randomString.toString();
    }

    public void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            // igrnored
        }
    }

}
