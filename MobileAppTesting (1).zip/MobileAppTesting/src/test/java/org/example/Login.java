package org.example;

import io.appium.java_client.MobileElement;
import org.testng.Assert;

public class Login {

    public static void Test3FunctionFlow(){
        Driver driver = Driver.getInstance();

        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550993", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");

        // Handle permissions
//        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); // Contacts
//        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); // Nearby

        //Subscribe Slab plan
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Kenya", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
//        MobileElement subscribeButton = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/btn_subscribe");
//        // Check if the 10 minutes plan is already subscribed
//        if(subscribeButton.getText().equalsIgnoreCase("subscribed")){
//            driver.clickElementID("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout");
//        }
//        else{
//            driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");}
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");//Daily plan
        driver.clickElementID("com.slickcall.app.dev:id/ll_pay_with_wallet");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.Button");

        // Make call by entering number in Dialpad
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Dialpad\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.typeAndClick("com.slickcall.app.dev:id/text_field", "923150999111", "com.slickcall.app.dev:id/fab_call");
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_foreground_only_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button"); //Nearby permission
        driver.sleep(5000);
        driver.clickElementID("com.slickcall.app.dev:id/fab_disconnect_call");

        // Perform scroll up to logout
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.scrollUp();
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");


    }
    public static void WrongCredentailsLogin(){
        Driver driver = Driver.getInstance();
        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550993", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "567543");
        driver.sleep(200);
        MobileElement InvalidCode = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/text_details");
        Assert.assertTrue(InvalidCode.isDisplayed(), "Invalid code, please try again.");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");

        // Perform scroll up to logout
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.scrollUp();
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[6]/android.widget.LinearLayout");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.GridView/android.widget.LinearLayout[5]/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView");
        driver.clickElementID("com.slickcall.app.dev:id/btn_logout");

    }
    public static void testLogin(){
        Driver driver = Driver.getInstance();

        // permission popup
        driver.clickElementID("com.slickcall.app.dev:id/btn_allow"); // Popup for Permission
        driver.clickElementID("com.android.permissioncontroller:id/permission_allow_button");
        driver.clickElementID("com.slickcall.app.dev:id/imageView_arrow");

        // Search and select country
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "United States", "com.slickcall.app.dev:id/textView_countryName"); // EditText, Button/TextView

        // Enter phone number and proceed
        driver.typeAndClick("com.slickcall.app.dev:id/phone_input", "2025550993", "com.slickcall.app.dev:id/btn_send_code");

        // Enter OTP
        driver.typeElementID("com.slickcall.app.dev:id/firstPinView", "123456");


    }
}
