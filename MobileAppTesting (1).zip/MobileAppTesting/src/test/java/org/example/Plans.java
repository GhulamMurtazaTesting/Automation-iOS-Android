package org.example;

import io.appium.java_client.MobileElement;

public class Plans {

    public static void ActivatePlans()

    {
        Driver driver = Driver.getInstance();

        //Do Top-up
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[5]/android.widget.RelativeLayout/android.widget.ImageButton");
        //Continue By card
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.EditText","4242424242424242");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[2]/android.view.View/android.widget.EditText", "1236");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.view.View[1]/android.widget.EditText","123");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText","Kashif");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.view.View[4]/android.view.View/android.view.View[1]/android.view.View/android.view.View");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.CheckedTextView[2]");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View[2]/android.widget.Button");

        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[4]/android.widget.RelativeLayout/android.widget.ImageButton");
        //Continue by PayPal
        driver.clickElementID("com.slickcall.app.dev:id/rbPaypal");
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View/android.view.View[1]/android.view.View/android.widget.EditText", "sb-ccomx8014149@personal.example.com");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.widget.Button");
        driver.typeElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.widget.EditText","DMn=40hu");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[2]/android.view.View[2]/android.widget.Button");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.Button");
        driver.clickElementID("com.slickcall.app.dev:id/refresh_balance_icon");
        driver.sleep(5000);

        //check rates - Slab with Wallet
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Ethiopia", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        MobileElement isSubscribed = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/btn_subscribe");
        // Check if the 10 minutes plan is already subscribed
        if(isSubscribed.getText().equalsIgnoreCase("subscribed")){
            driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout");
        }
        else{
            driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");}
        driver.clickElementID("com.slickcall.app.dev:id/ll_pay_with_wallet");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        //check rates - Slab with Card
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Ethiopia", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        MobileElement isSubscribed1 = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/btn_subscribe");
        // Check if the 10 minutes plan is already subscribed
        if(isSubscribed1.getText().equalsIgnoreCase("subscribed")){
            driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout");
        }
        else{
            driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");}
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View[2]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");

        //check rates - Slab with PayPal
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Ethiopia", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        MobileElement isSubscribed2 = driver.getHeavyDriver().findElementById("com.slickcall.app.dev:id/btn_subscribe");
        // Check if the 10 minutes plan is already subscribed
        if(isSubscribed2.getText().equalsIgnoreCase("subscribed")){
            driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.RelativeLayout");
        } else if (isSubscribed2.getText().equalsIgnoreCase("subscribed")) {
            driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[3]/android.widget.RelativeLayout");
        } else{
            driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");}
        driver.clickElementID("com.slickcall.app.dev:id/rbPaypal");
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/refresh_balance_icon");

        //check rates - Daily with Wallet
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Ethiopia", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/ll_pay_with_wallet");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");

        //check rates - Daily with Card
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Nigeria", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/llContinueWithCard");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View[2]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");

        //check rates - Daily with PayPal
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Ghana", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/refresh_balance_icon");

        //check rates - Unlimited with Wallet
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Canada", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementID("com.slickcall.app.dev:id/btn_subscribe");
        driver.clickElementID("com.slickcall.app.dev:id/ll_pay_with_wallet");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementID("com.slickcall.app.dev:id/btn_confirm");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");

        //check rates - Unlimited with Card
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "Bangladesh", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/llContinueWithCard");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View[2]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");

        //check rates - Unlimited with PayPal
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout[1]/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout");
        driver.clickElementID("com.slickcall.app.dev:id/et_search");
        driver.typeAndClick("com.slickcall.app.dev:id/editText_search", "France", "com.slickcall.app.dev:id/textView_countryName");
        driver.clickElementID("com.slickcall.app.dev:id/tv_rate_view_more_plans_lable");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.RelativeLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.RelativeLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/tvContinueBtn");
        driver.clickElementXpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[3]/android.widget.Button");
        driver.clickElementXpath("//android.widget.FrameLayout[@content-desc=\"Account\"]/android.widget.FrameLayout/android.widget.ImageView");
        driver.clickElementID("com.slickcall.app.dev:id/refresh_balance_icon");
    }
}
